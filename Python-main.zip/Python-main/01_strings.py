#b="Vedant's" #-->Use this if you have single quotes in your strings
#b= 'Vedant''s'
b='''Vedant"s and
 Vedant's'''
print(b)
#print(type(b))

