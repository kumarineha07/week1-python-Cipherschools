'''
This problem is a solution of
Problem 1 of Code with Harry Practise set!
'''
#This is also a comment just like the above line


print('''Twinkle, twinkl, little star,
     How I wonder what you are!
     Up above the world so high,
     Like a diamond in the sky.''')