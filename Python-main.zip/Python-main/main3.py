#Author: Harry
#Licenced to:ABC Company

print("Hello world")
