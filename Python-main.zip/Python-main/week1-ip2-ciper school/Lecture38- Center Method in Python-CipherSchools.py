#center method
# name= "himanshu"
# print(name.center(11,"*"))
name=input("Enter your name: ")
print(name.center(len(name)+8,"*"))
