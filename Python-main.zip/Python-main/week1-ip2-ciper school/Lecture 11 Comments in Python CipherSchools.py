# this is a comment 
print("Hello World!")
print('Himanshu Garg') #its my name 
print('12215954') #its my registration number
print('KOC09-50') # its my section & roll number
'''I am learning python coding langaunge from CipherSchools
'''