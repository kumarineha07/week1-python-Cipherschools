print('hello world')
print("hello \"wolrd\"")
print('lineA \tlineB')
print('lineA \n lineB')
print(r'lineA \n lineB')
print(2*3)
print(2+3)
print(2-3)
print(2**3)
print(2//3)
print(2/3)
print((2+3)*4/2)
name = "Himanshu"
print(name)
name = 123
print(name)
_name = (789)
print(_name)
p_r = "Himanshu Garg"
print(p_r)




