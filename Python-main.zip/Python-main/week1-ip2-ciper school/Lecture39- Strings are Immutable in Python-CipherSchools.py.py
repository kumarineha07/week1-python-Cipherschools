# strings are immutable
string = "string"
new_string = string.replace('t','T')
print(new_string)
