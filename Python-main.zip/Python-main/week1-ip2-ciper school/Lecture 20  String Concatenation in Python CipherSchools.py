first_name = "Himanshu " 
last_name = "Garg"
full_name = first_name + " " + last_name 
print(full_name)
print(first_name + "3")
print(first_name + str(3))
print(first_name *3)