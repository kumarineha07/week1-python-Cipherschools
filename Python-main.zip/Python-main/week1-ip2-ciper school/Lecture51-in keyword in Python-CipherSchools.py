name = "Himanshu"
# in keyword
# if with in
if 'H' in "Himanshu":
    print("H is present in name")
else:
    print("not present")
    
