print("Hello World!")
print('Hello World!')
print("Hello 'hello' World!")
print('Hello "hello" World!') 
