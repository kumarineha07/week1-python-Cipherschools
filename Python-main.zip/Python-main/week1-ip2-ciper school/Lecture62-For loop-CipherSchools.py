for i in range(1,11):
    print(f"hello world:{i}")
