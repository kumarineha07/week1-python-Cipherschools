# check two conditions at same time
# and, or
name='abc'
age = 19
# if name=='abc' and age==19:
  #  print("condition true")
# else:
  #  print("condition false")

if name == 'abc' or age > 19:
    print("condition true")
else:
    print("condition false ")
