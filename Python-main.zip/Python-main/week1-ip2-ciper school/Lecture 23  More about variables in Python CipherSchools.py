name, rollno = "Himanshu", "50"
print("My name is "+ name + "\tMine roll is " + rollno )
q=w=e=2
print(q+w+e)