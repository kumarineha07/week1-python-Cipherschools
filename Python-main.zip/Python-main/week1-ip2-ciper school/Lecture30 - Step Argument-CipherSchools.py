# print("Himanshu"[-1::-1])
print("Himanshu"[::-1]) # trick
