# name = "tomato" #t=0(-6) o=1(-5) m=2(-4) a=3(-3) t=4(-2) o=5(-1)
# print(name[3]) #a
# print(name[-2]) #t

name = "tomato"
print(name[0:4]) #toma
print(name[3:6]) #ato
print(name[-3:6]) #ato
print(name[2:]) #mato
print(name[:3]) #tom