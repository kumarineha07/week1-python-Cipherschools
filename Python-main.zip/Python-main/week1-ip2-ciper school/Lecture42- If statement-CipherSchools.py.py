# syntax
# if conditon

age= input("Enter your age: ")
age=int(age)
if age>=14:
    print("line a")
    print("You are above")
