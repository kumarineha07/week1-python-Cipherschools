a=458
b=15

print("The remainder when a is divided by b is", a%b)