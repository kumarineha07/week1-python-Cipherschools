#adding the list items

list=[10,20,30]

list.insert(2,40)
#print(list1)

#append items
#for adding the items  at the end of the list
#list=[10,20,30]
