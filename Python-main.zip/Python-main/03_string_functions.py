story="Once upon a time there was a youtuber named Harry who uploaded python course with a notes"

#String Functions
print(len(story))
print(story.endswith("notes"))
print(story.count("c"))
print(story.replace("Harry","CodeWithHarry"))