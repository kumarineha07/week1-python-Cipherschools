p = int(input())
t = int(input())
r =float(input())
a = p((1+r)/100)**t
ci = a - p
print(ci)