#greeting="Good Morning"
#name= "Vedant"
#print(type(name))
#Concatenating two strings
#c= greeting+name
#print(c)
name="Vedant"
print(name[3])
