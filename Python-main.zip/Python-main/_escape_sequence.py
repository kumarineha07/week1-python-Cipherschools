story="Harry is good.\nhe is very good"
print(story)