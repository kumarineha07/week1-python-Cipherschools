#change the list items

list=[30,60,10,20,80]

#list[1]=90
#list[2]='hello'

#print(list)

#change a range of list items

#list1[1:3]=["hi,""hello"]
#insert more items than replace then new items will be inserted at the index that we provided
#list=[10,20,40]
#list[1:2]