#remove a specified item from the list
#remove()

#mylist=['john','peter','rohan']
#mylist remove(rohan)
#print(mylist)
