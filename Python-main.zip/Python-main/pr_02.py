letter='''Dear <|NAME|>,
You are selected!

Date:<|DATE|>
'''
name=input("")